# ExpectSEE

Companion R package for *Estimating (High-Dimensional) Systems of Equations
for Expectiles*, by Hui-Ching Chuang, O-Chia Chuang, and Zaichao Du (2026,
working paper).

Package authors: Hui-Ching Chuang, O-Chia Chuang, Zaichao Du, and Zhenhong Huang.
Maintainer: Hui-Ching Chuang <hcchuang@mail.ntpu.edu.tw>.

## Install and run

Download the source package and `paper_example.R` from
<https://hcchuang.github.io/expectsee/>. In R:

```r
install.packages(
  "https://cran.r-project.org/src/contrib/Archive/SALES/SALES_1.0.0.tar.gz",
  repos = NULL, type = "source"
)
install.packages("ExpectSEE_0.2.11.tar.gz", repos = NULL, type = "source")
source("paper_example.R")
```

The example is also installed with the package:

```r
source(system.file("paper_example.R", package = "ExpectSEE"))
```

SALES contains compiled code: source installation requires the R-compatible
build tools for your platform (Rtools on Windows).

The release example uses R 4.5.1 and SALES 1.0.0. It generates
three synthetic series locally and requires no empirical bank data or downloads.
Its expectile level is 0.80, chosen for a small, well-behaved demonstration;
the paper uses 0.99855. It illustrates the workflow, not the paper's numerical
results.

## Paper workflow

- `sals()` and `sfgals()` fit the fixed-dimensional system; `sfgals()` accounts
  for estimated first-stage residual regressors when `se = "generated"`.
- `see_spec_test()`, `see_wald_test()`, and `see_linear_test()` implement
  fixed-dimensional specification, dependence, and symmetry tests.
- `see_ts_splits()`, `hdsals()`, and `hdsfgals()` implement expanding-window
  selection with direct-LASSO coefficients. The example uses `lambda.min`
  in both stages, 100 candidate penalties, nested first-stage refitting,
  the full Stage-2 lag candidate set, and penalties on every slope. Intercepts
  are unpenalized; estimated coefficients are returned in original units.
- `see_system_map()` and `see_irfe()` construct reduced-system, model-implied
  responses. The example checks a locally attracting fixed point and reports
  point responses to positive and negative innovations with `ci = FALSE`.

Fit objects retain coefficient and fit summaries, residuals, selected supports,
and sparse edges. The example displays these without empirical-data dependencies.
High-dimensional formal inference is not supplied by the example. Response paths
describe the fitted system; they are not identified causal effects. Finding a
locally attracting root does not establish global uniqueness or global stability.

Use `citation("ExpectSEE")` for the working-paper citation. The package is
distributed under the MIT license; SALES is a separately installed dependency
with its own license.
